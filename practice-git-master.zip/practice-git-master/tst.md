this is text that is replacing the first line entirely
This is a new line of text
More text More text More text More text More text More text More text
More text
More text
More text More text
More text More text More text

-------
# A quotation

> “Nobody ever figures out what life is all about, and it doesn't matter. Explore the world. Nearly everything is really interesting if you go into it deeply enough.” ― Richard Feynman

-------

Add more inspirational quotes here, if you like?
