#it's safe to run this on any Python-equipped machine.
#reference: https://www.python.org/dev/peps/pep-0020/

import this