5.times do
  puts "Hello World!"
end
