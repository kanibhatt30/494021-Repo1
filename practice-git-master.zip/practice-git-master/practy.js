var thing = function() {
  console.log('whatup');
}

thing();

console.log('check out this awesome new feature!');
console.log('check out this awesome new feature again!');
